package lab4;

import java.util.Random;

/**
 * A random assortment of methods reviewing topics that should improve your
 * programming skills in using Java Control Structures (selection structures,
 * repetition structures, and nested Loops), and
 * java.util.Random
 * 
 *
 */

public class UtilityClass {
	private UtilityClass() {

	}

	/**
	 * Write a static method to determine if a number x is evenly divisible by a
	 * number y. if x divided by y has no remainder. Two numbers are evenly
	 * divisible if either is evenly divisible by the other. Thus, 15 and 3 are
	 * evenly divisible, and 4 and 16 are evenly divisible, whereas 16 and 3 are
	 * not, and 8 and 0 are not.
	 * 
	 * evenlyDivisible that accepts two integer parameters and returns string value  
	 * 
	 * <p>
	 * For example:
	 * </p>
	 * 
	 * <pre>
	 * if x= 10 and y =5 then return "10 and 5 are evenly divisible"
	 * if x= 4 and y =32  then return "4 and 32 are evenly divisible"
	 * if x= 0 and y=0  then return "Invalid input"
	 * if x =17 and y =4 then return "17 and 4 are NOT evenly divisible"
	 * </pre>
	 * 
	 * @param a : int input value 
	 * @param b : int input value 
	 * @return  String value see above 
	 */
	public static String evenlyDivisible(int a, int b) {


		
		
		
		/* Your implementation  here. */
	}
	
	
	/**
	 * Write a static method to compute and return a random integer between x and y,
	 * inclusive, assuming x is less than or equal to y.
	 * <p>
	 * This method should not assign values to x or y nor print the random number.
	 * </p>
	 * <p>
	 * For example:
	 * </p>
	 * 
	 * <pre>
	 * if x= 0 and y =10 then return any integer belonging to {0,1,2,3,4,5,6,7,8,9,10}
	 * if x= 2 and y =7  then return any integer belonging to {2,3,4,5,6,7}
	 * </pre>
	 * 
	 * 
	 * @param x : int input the lower limit 
	 * @param y : int input the upper limit 
	 * 
	 * @pre.
	 * <p>
	 *              <strong> Precondition </strong>
	 *              </p>
	 * <p>x is less than or equal to y</p>
	 * 
	 * 
	 * @return  a random integer between x and y,
	 * inclusive, assuming x is less than or equal to y.
	 */

	public static int getRandomNumber(int x, int y) {


		
		/* Your implementation  here. */
	}

	/**
	 * Write a static method to generate string of random number the number of generated random
	 * number is defined by integer value given by n the generated random integers
	 * should be between x and y (inclusive).
	 * Assuming n is positive and x is less than or equal to y.
	 * <p>
	 * For example:
	 * </p>
	 * 
	 * <pre>
	 * if n=5, x= 5 and y =10 then some of possible returned strings (6)(8)(9)(10)(7) 
	 * or (8)(9)(6)(6)(7) , (9)(6)(9)(6)(9) .
	 * if n=2,  x= 2 and y =7  then some of possible returned strings (6)(7) 
	 * or (3)(4) , (5)(6),...
	 * </pre>
	 * 
	 *@pre.
	 *<p>
	 *              <strong> Precondition </strong>
	 *              </p>
	 * <p>n is positive and x is less than or equal to y</p>
	 * 
	 * @param n : number of random integers
	 * @param x : int input the lower limit 
	 * @param y : int input the upper limit 
	 * @return  generate string of random number the number of generated random
	 * number is defined by integer value given by n the generated random integers
	 * should be between x and y (inclusive).
	 */

	public static String stringOfRandomInt(int n, int x, int y) {


		
		/* Your implementation  here. */
	}

	/**
	 * Write a static method to determine if the given integer is perfect square. 
	 * <p>
	 * Note: The numbers 0, 1, 4, 9, 16, 25, ... are perfect squares.
	 * </p>
	 * 
	 * <p>
	 * For example:
	 * </p>
	 * 
	 * <pre>
	 * if n = 0 then 	return "Integer 0 is Perfect Square"
	 * if n= 10  then  return "Integer 10 is NOT Perfect Square"
	 * if n= 63 then  return "Integer 63 is NOT Perfect Square"
	 * if n= 64  then  return "Integer 64 is NOT Perfect Square"
	 * </pre>
	 * 
	 * 
	 * 
	 * @param n :int input integer
	 * 
	 * @pre.
	 *          <p>
	 *          <strong> Precondition </strong>
	 *          </p>
	 *          <p>
	 *          You may assume that the integer n is No negative integer
	 *          </p>
	 * 
	 * @return  String value 
	 */

	public static String isPerfectSquare(int n) {
		// finding the square root of given number 
		

			
		
		/* Your implementation  here. */

	}
	
	/**
	 * Write a static method to determine if the given input <code>n</code> integer 
	 * is palindrome integer. 

	 * <p>
	 * For example:
	 * </p>
	 * 
	 * <pre>
	 * if n = 0 then 	return "Integer 0 is Palindrome"
	 * if n= 10  then  return "Integer 10 is NOT Palindrome"
	 * if n= 3635363 then  return "Integer 3635363 is Palindrome"
	 * if n= 121121  then  return "Integer 121121 is Palindrome"
	 * if n= 112545214 then return "Integer 112545214 is NOT Palindrome" 
	 * </pre>
	 * 
	 * 
	 * @param n : int input value 
	 * @return <code>n</code> is palindrome integer then return true. Otherwise, return false
	 */
	public static String isPalindromeInt(int n) {

        
        
        /* Your implementation  here. */
    }
		
	/**
	 *  
	 * Write a static method below that takes <code>int</code> number as 
	 * input argument and returns the sum of the digits of that number.
	 * <p> For example: </p>
	 * <pre>
	 * if number = 2134 then return 2+1+3+4=10
	 * if number = 29107 then return 2+9+1+0+7=19
	 * if number = 5842  then return 19
	 * if number = 1002  then return 3
	 * </pre>
	 * You will need a loop, and <strong>your loop must not execute more iterations than necessary, and you cannot use break or continue</strong>.
	 * <strong>Make sure the method compiles without errors and returns the correct result when invoked.</strong>
	 * @param number : int input value 
	 * @return the sum of the digits of any given integer value 
	 */
	
	public static int digitSum(int number) {

		
        
        /* Your implementation  here. */
	}
	
	
	
	
	
	/**
	 
	 * 
	 * Write a static method  below that takes <code>int</code> number 
	 * as input argument and returns the sum of the even digits of that number.
	 * <p> For example: </p>
	 * <pre>
	 * if number = 5842 then return 8+4+2=14
	 * if number = 1002 then return 0+0+2=2
	 * if number = 19357  then return 0
	 * if number = 2864  then return 20
	 * </pre>
	 * You will need a loop, and <strong>your loop must not execute more iterations than necessary, and you cannot use break or continue</strong>.
	 * <strong>Make sure the method compiles without errors and returns the correct result when invoked.</strong>
	 * @param number : int input value 
	 * @return the sum of the even digits of any given integer.
	 */
	
	
	public static int sumEvendigits(int number) {

        
        /* Your implementation  here. */
	}
	
	/**
	 * <p><strong> Modular Arithmetic</strong> </p> 
	 * <p><strong> Definition: </strong><em>
	 *  If {@code a} and {@code b}  are integers and {@code m} is a positive integer, 
	 *  then {@code a} is <b>congruent</b> to {@code b}  modulo {@code m} if <b> {@code m} divides {@code a-b} </b>. </em>
	 *  </p><p> In the other words, two integers are congruent mod {@code m} if and only if 
	 *  they have the <b> same remainder when divided by {@code m} </b> .</p>
	 * 
	 *  
	 *  <pre>
	 *  Example:
	 *  
	 *  isCongruent ( 81,199,5) returns "81 and 199 NOT congruent modulo 5"
	 *  isCongruent ( -8,8, 5) returns "-8 and 8 NOT congruent modulo 5"
	 *  isCongruent ( 24, 14, 6) returns "24 and 14 NOT congruent modulo 6"
	 *  isCongruent ( 10, 26, 8) returns "10 and 26 congruent modulo 8" 
	 *  isCongruent ( 17, 5, 6) returns "17 and 5 congruent modulo 6"
	 *  isCongruent ( -1,1, 2) returns "-1 and 1 congruent modulo 2" 
	 *  isCongruent ( -8,2, 5) returns "-8 and 2 congruent modulo 5" 
	 *  isCongruent ( 38,23, 15) returns "38 and 23 congruent modulo 15"
	 *  </pre>
	 * 
	 * 
	 * @param a integer not equal to zero
	 * @param b integer not equal to zero 
	 * @param m integer not equal to zero
	 * @return String value See above  
	 * @pre.
	 * 		{@code m > 0} , {@code a != 0}  , {@code b != 0} 
	 */
	
	
	public static String  isCongruent (int a , int b , int m ) {
		
		// we need to test for positive and negative integers 
		// m should be positive, but a and b can be positive or negative 
		// for negative integer operation % is not equivalent to mod operation  
		//  -7%10 = -7  but (-7 mod 10)=3
		

		
		
		/* Your implementation  here. */
		
		
	}
	
	/**
	 * <p><strong> Primes</strong> </p>
	 * <p> A <em> positive integer </em> {@code n > 1} is called <strong> prime</strong> 
	 * if the only positive factors of {@code n}  are {@code  1}  and {@code  n} . 
	 * A positive integer that is greater than one and is not prime is called <strong> composite</strong>.</p>
	 * <p> An integer {@code  n} is <strong> composite </strong> 
	 * if and only if there exists an integer {@code a} such that
	 * <strong> <em>  {@code a}  divides {@code n}  </em></strong> and {@code 1 < a < n}.</p>
	 * 
	 * <p> <strong> Hint:  1 is neither prime nor composite. It forms its own special category as a "unit".</strong></p>
	 * 
	 * <p> This method checks the positive integer if it is prime or not.</p>
	 *  <pre>
	 *  Example:
	 *  
	 *  isPrime ( -5) returns "-5 is NOT Prime" 
	 *  isPrime ( 6) returns "6 is NOT Prime" 
	 *  isPrime ( 25) returns "25 is NOT Prime" 
	 *  isPrime ( 2) returns "2 is Prime"  
	 *  isPrime ( 3) returns "3 is Prime"  
	 *  isPrime ( 13) returns "13 is Prime"  
	 *  isPrime ( 17) returns "17 is Prime"  
	 *  isPrime ( 29) returns "29 is Prime"  
	 *  </pre>
	 * 
	 * @param n positive integer 
	 * @return String value see above 
	 * @pre.
	 * 		{@code n > 0}  
	 */
	public static String isPrime(int n) {
		
		
        
        /* Your implementation  here. */
		
	}	
	
}
