package lab1;
/**
 * Use this Class to test the method that you 
 * implemented 
 * 
 *
 */
public class Lab1ClassApp {

	public static void main(String[] args) {
		
		System.out.println("Test mulDiff(1, 2) = "+ Lab1Class.mulDiff(1, 2));
		System.out.println("Test sumSquares(1, 2) = "+Lab1Class.sumSquares(1, 2));
		System.out.println("Test compute(4) = "+Lab1Class.compute(4));
		System.out.println("Test getBMI(75,15,45) = "+Lab1Class.getBMI(75,15,45));
		System.out.println("Test numRevolutions(720) = "+Lab1Class.numRevolutions(720));
		System.out.println("Test fixAngle(720) = "+Lab1Class.fixAngle(720));
		System.out.println("Test avg(1,2,4) = "+Lab1Class.avg(1,2,5));
		System.out.println("Test isEven(7)= "+Lab1Class.isEven(7));
		
		/* you can add more test */
	}
	
}
