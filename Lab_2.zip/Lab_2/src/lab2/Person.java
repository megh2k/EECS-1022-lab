package lab2;

/**
 * 
 * A simple class Person. person object store name, address, phone and email of
 * any given person
 *
 */
public class Person {

	/* To be able to complete this Class, you need to read  the API of this class
	 * Hint: Use the PersonTest class to help you test you work  
	 * 
	 * */

}
