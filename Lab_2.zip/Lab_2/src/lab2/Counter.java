package lab2;

/**
 * A simple counter. A counter keeps track of an integer value that can be
 * changed in steps of 1 (the counter can be incremented or decremented). A
 * counter provides a method to get and set the value of the counter value .
 * 
 * 
 *
 */
public class Counter {
	/* To be able to complete this Class, you need to read  the API of this class
	 * Hint: Use the CounterTest class to help you test you work  
	 * 
	 * */
}


	
	
	
	
	
	